# Universal Selenium Automation Script

from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager
import time

# Update this to your server URL or local file path
url = "http://localhost:8000/index.html"

chrome_options = Options()
chrome_options.add_argument('--headless')
chrome_options.add_argument('--no-sandbox')
chrome_options.add_argument('--disable-dev-shm-usage')

driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=chrome_options)

test_cases = [
    {'username': 'validUser', 'password': 'validPass', 'expected_title': 'Dashboard'},
    {'username': 'invalidUser', 'password': 'invalidPass', 'expected_error': 'Login Failed'}
]

for case in test_cases:
    driver.get(url)

    username_input = driver.find_element("id", "username")
    password_input = driver.find_element("id", "password")

    username_input.clear()
    username_input.send_keys(case['username'])
    password_input.clear()
    password_input.send_keys(case['password'])

    login_button = driver.find_element("xpath", "//button[text()='Login']")
    login_button.click()

    time.sleep(2)

    screenshot_filename = f"{case['username']}_result.png"
    driver.save_screenshot(screenshot_filename)

    if 'expected_title' in case:
        if driver.title == case['expected_title']:
            print(f"Test Passed for: {case['username']} (Valid Login)")
        else:
            print(f"Test Failed for: {case['username']} (Expected title not found)")
    elif 'expected_error' in case:
        message = driver.find_element("id", "message").text
        if case['expected_error'] in message:
            print(f"Test Passed for: {case['username']} (Invalid Login Detected)")
        else:
            print(f"Test Failed for: {case['username']} (Error message not found)")

driver.quit()
